from distutils.core import setup

setup(name="chengge",version="1.0",description="chengge's module",author="dongge",py_modules=["Testmsk.recvmsg","Testmsk.sendmsg"])
